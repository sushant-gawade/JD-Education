<?php
    require($_SERVER['DOCUMENT_ROOT']."//19//_preload/php//_dbconnect.php");
    if($_SERVER['REQUEST_METHOD']=="GET"){
      $str = "";
      $q = "SELECT * FROM `event`";
      $res = mysqli_query($con,$q);
      $num = mysqli_num_rows($res);
      for ($i=0; $i < $num; $i++){ 
        $fet = mysqli_fetch_assoc($res);
        $str = $str . 
        '<div class="col-md-6 d-flex align-items-stretch">
        <div class="card">
          <div class="card-img">
            <img src="'. $fet['image_url'] .'" alt="...">
          </div>
          <div class="card-body">
            <h5 class="card-title"><a href="">'. $fet['title'] .'</a></h5>
            <p class="font-italic text-center">'. $fet['date_time'] .'</p>
            <p class="card-text">'. $fet['text'] .'</p>
          </div>
        </div>
      </div>';
      }
      echo $str;
    }
    mysqli_close($con);
?>
