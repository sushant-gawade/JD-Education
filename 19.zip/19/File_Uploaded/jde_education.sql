-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2023 at 08:02 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jde_education`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `sr` int(10) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `teacher_name` varchar(200) NOT NULL,
  `joined_student` varchar(200) NOT NULL,
  `quiz_url` varchar(200) NOT NULL,
  `image_url` varchar(100) NOT NULL,
  `likes` varchar(10) NOT NULL,
  `teacher_image_url` varchar(100) NOT NULL,
  `text` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`sr`, `title`, `description`, `course_name`, `teacher_name`, `joined_student`, `quiz_url`, `image_url`, `likes`, `teacher_image_url`, `text`) VALUES
(1, 'Website Design', 'Et architecto provident deleniti facere repellat nobis iste. Id facere quia quae dolores dolorem tempore.', 'Web Development', 'Antonio', '50', '', 'https://bootstrapmade.com/demo/templates/Mentor/assets/img/course-1.jpg', '10', 'https://bootstrapmade.com/demo/templates/Mentor/assets/img/trainers/trainer-1.jpg', 'Et architecto provident deleniti facere repellat nobis iste. Id facere quia quae dolores dolorem tempore.');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `Sr` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `image_url` varchar(200) NOT NULL,
  `date_time` datetime NOT NULL,
  `text` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Sr`, `title`, `image_url`, `date_time`, `text`) VALUES
(1, 'Introduction to webdesign', 'https://bootstrapmade.com/demo/templates/Mentor/assets/img/course-1.jpg', '2022-08-17 22:30:43', 'Lorem ipsum dolor sit amet, consectetur elit, sed do eiusmod tempor ut labore et dolore magna aliqua'),
(2, 'Marketing Strategies', 'https://bootstrapmade.com/demo/templates/Mentor/assets/img/events-2.jpg', '2022-08-17 22:35:01', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem doloremque laudantium, totam rem aper');

-- --------------------------------------------------------

--
-- Table structure for table `login_credit`
--

CREATE TABLE `login_credit` (
  `Sr` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_credit`
--

INSERT INTO `login_credit` (`Sr`, `username`, `password_hash`) VALUES
(2, 'gclikhar@mitaoe.ac.in', '1234'),
(1, 'hardikjade2808@gmail.com', '8182');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`Sr`);

--
-- Indexes for table `login_credit`
--
ALTER TABLE `login_credit`
  ADD PRIMARY KEY (`username`,`Sr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `sr` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `Sr` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
