<?php
    // $user = "Hardik";
    // $pwd = 1234;
    $host = "localhost";
    $user = "root";
    $pwd = "";
    $data_base = "jde_education";
    $con = mysqli_connect($host,$user,$pwd,$data_base);
    $db_err = false;
    if(!$con){
        echo   
        $con .
        `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Fail!</strong> Sorry Fail To Connect Please Try Again.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>`;
        $db_err = true;
    }
    else{
        $db_err = false;
    }
?>