<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>JDE Education | Teachers</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">
  <link href="http://localhost/19/assets/img/favicon.png" rel="icon">
  <link href="http://localhost/19/assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="http://localhost/19/assets/vendor/aos/aos.css" rel="stylesheet">
  <script src="http://localhost/19/assets/js/jquery.js"></script>
  <link href="http://localhost/19/assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="http://localhost/19/assets/css/animinate.css">
</head>

<body>

  <!-- Navbar Here -->

  <script>
    $(function() {
      $("#loadheader").load("http://localhost/19/_preload/_navbar.php");
    });
  </script>
  <div id="loadheader"></div>


  <!-- Navbar End Here -->

  <main id="main" data-aos="fade-in">
    <div class="breadcrumbs">
      <div class="container">
        <h2>Uplaod Document</h2>
        <p>Here You Upload The File. </p>
      </div>
    </div>

    <!-- Noification Manager Here -->
    <div class="par_s"></div>


    <!-- Main Form Here -->
    <div class="container my-4">
      <form action="http://localhost/19/_preload/php/upload.php" method="POST" enctype="multipart/form-data">
        <div class="form-group my-3 border border-dark py-2 px-2">
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo facilis corrupti laboriosam ex et recusandae laudantium aspernatur, modi tempore suscipit!</p>
        </div>
        <div class="form-group my-3 border border-dark py-2 px-2">
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor ab in omnis quam explicabo. Magni, cupiditate dolores, at doloremque itaque error excepturi accusantium debitis illo ad explicabo ab? Eum quidem nemo repudiandae laudantium sapiente aperiam nihil ad fugit soluta odit, tenetur in est iure, quo perspiciatis esse pariatur asperiores nulla molestiae, quae debitis quam vero hic dolore! Ipsum rerum excepturi quibusdam et praesentium. Placeat culpa suscipit excepturi est non fugit recusandae accusantium odio enim pariatur, magni officiis saepe dignissimos quas rerum explicabo soluta sunt possimus? Ipsum, maiores similique esse laudantium, fugit, a ratione molestias voluptatum voluptatem obcaecati dolor rem adipisci!</p>
        </div>
        <div class="form-group form-check text-center my-3" style="display: block;">
          <input type="file" name="file" class="target" required>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block mx-auto" id="target">Submit</button>
      </form>
    </div>
    <!-- End Main Form Here -->

    <!-- Upload Js Brain -->

    <script>
      function success() {
        let chi = document.createElement("div");
        let par_s = document.getElementsByClassName("par_s")[0];
        chi.innerHTML = `
          <div class="alert alert-success alert-dismissible my-2 animate__animated animate__backInUp" role="alert">
          <strong>Success</strong> Document Uploaded Successfully.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>`;
        par_s.appendChild(chi);
      }

      function fail() {
        let chi = document.createElement("div");
        let par_s = document.getElementsByClassName("par_s")[0];
        chi.innerHTML = `
          <div class="alert alert-danger alert-dismissible animate__animated animate__backInDown mt-2" role="alert">
          <strong>Sorry</strong> Fail To Upload The Document.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>`;
        par_s.appendChild(chi);
      }

      function hide(){
        // Hide Target Here
        let tar = document.getElementsByClassName("target")[0];
        let tar_s = document.getElementById("target");
        tar.style.display = "none";
        tar_s.style.display = "none";
        // EventHandler

      }
    </script>


    <!-- End Js Brain  -->
    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
      $f = $_FILES['file'];
      try {        
        move_uploaded_file($f['tmp_name'],"C://xampp//htdocs//19//File_Uploaded/".$f['name']);
        $temp = "true";
      } catch (\Throwable $th) {
        $temp = "false";
      }
      if ($temp == "true") {
        echo "<script>
          success();
          hide();
        </script>";
      }
      if ($temp == "false") {
        echo "
        <script>
          fail();
        </script>
        ";
      }
    }
    ?>
    <!-- Start Footer Here -->

    <script>
      $(function() {
        $("#loadfooter").load("http://localhost/19/_preload/_footer.html");
      });
    </script>
    <div id="loadfooter"></div>
    <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
    <div id="preloader"></div>

    <!-- End Footer Here -->

    <!-- Here Main Script File -->
    <script src="http://localhost/19/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="http://localhost/19/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="http://localhost/19/assets/vendor/php-email-form/validate.js"></script>
    <script src="http://localhost/19/assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="http://localhost/19/assets/vendor/counterup/counterup.min.js"></script>
    <script src="http://localhost/19/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="http://localhost/19/assets/vendor/aos/aos.js"></script>
    <script src="http://localhost/19/assets/js/main.js"></script>
</body>

</html>