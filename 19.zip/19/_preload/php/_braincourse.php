<?php
    require($_SERVER['DOCUMENT_ROOT']."//19//_preload/php//_dbconnect.php");
    if($_SERVER['REQUEST_METHOD']=="GET")
    {
        $str = "";
        $q = "SELECT * FROM `courses`";
        $res = mysqli_query($con,$q);
        $num = mysqli_num_rows($res);
        for ($i=0; $i < $num; $i++){ 
          $fet = mysqli_fetch_assoc($res);
          $str = $str .
          '
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-4">
          <div class="course-item">
            <img src="'. $fet["image_url"] .'" class="img-fluid" alt="...">
            <div class="course-content">
              <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>'. $fet["course_name"] .'</h4>
              </div>
              <h3><a href="http://localhost/19/_preload/php/course-details.php?sr='. $fet['sr'] .'">'. $fet['title'] .'</a></h3>
              <p>'. $fet["text"] .'</p>
              <div class="trainer d-flex justify-content-between align-items-center">
                <div class="trainer-profile d-flex align-items-center">
                  <img src="'. $fet["teacher_image_url"] .'" class="img-fluid" alt="">
                  <span>'. $fet["teacher_name"] .'</span>
                </div>
                <div class="trainer-rank d-flex align-items-center">
                  <i class="bx bx-user"></i>&nbsp;'. $fet["joined_student"] .'
                  &nbsp;&nbsp;
                  <i class="bx bx-heart"></i>&nbsp;'. $fet["likes"] .'
                </div>
              </div>
            </div>
          </div>
        </div>
          ';
        }
        mysqli_close($con);
        echo $str;
    }
    if($_SERVER['REQUEST_METHOD']=="POST"){
      $q = "SELECT * FROM `courses` ORDER BY likes DESC";
      $res = mysqli_query($con,$q);
      $str = "";
      $num = mysqli_num_rows($res);
      if ($num>=3) {
        for ($i=0; $i < 3 ; $i++) { 
          $fet = mysqli_fetch_assoc($res);
          $str = $str . '
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-4">
          <div class="course-item">
            <img src="'. $fet["image_url"] .'" class="img-fluid" alt="...">
            <div class="course-content">
              <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>'. $fet["course_name"] .'</h4>
              </div>
              <h3><a href="http://localhost/19/_preload/php/course-details.php?sr='. $fet['sr'] .'">'. $fet['title'] .'</a></h3>
              <p>'. $fet["text"] .'</p>
              <div class="trainer d-flex justify-content-between align-items-center">
                <div class="trainer-profile d-flex align-items-center">
                  <img src="'. $fet["teacher_image_url"] .'" class="img-fluid" alt="">
                  <span>'. $fet["teacher_name"] .'</span>
                </div>
                <div class="trainer-rank d-flex align-items-center">
                  <i class="bx bx-user"></i>&nbsp;'. $fet["joined_student"] .'
                  &nbsp;&nbsp;
                  <i class="bx bx-heart"></i>&nbsp;'. $fet["likes"] .'
                </div>
              </div>
            </div>
          </div>
        </div>
          ';
        }
      }
      else{
        for ($i=0; $i < $num ; $i++) { 
          $fet = mysqli_fetch_assoc($res);
          $str = $str . '
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-4">
          <div class="course-item">
            <img src="'. $fet["image_url"] .'" class="img-fluid" alt="...">
            <div class="course-content">
              <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>'. $fet["course_name"] .'</h4>
              </div>
              <h3><a href="http://localhost/19/_preload/php/course-details.php?sr='. $fet['sr'] .'">'. $fet['title'] .'</a></h3>
              <p>'. $fet["text"] .'</p>
              <div class="trainer d-flex justify-content-between align-items-center">
                <div class="trainer-profile d-flex align-items-center">
                  <img src="'. $fet["teacher_image_url"] .'" class="img-fluid" alt="">
                  <span>'. $fet["teacher_name"] .'</span>
                </div>
                <div class="trainer-rank d-flex align-items-center">
                  <i class="bx bx-user"></i>&nbsp;'. $fet["joined_student"] .'
                  &nbsp;&nbsp;
                  <i class="bx bx-heart"></i>&nbsp;'. $fet["likes"] .'
                </div>
              </div>
            </div>
          </div>
        </div>
          ';
        }
      }
      echo $str;
      mysqli_close($con);
    }
?>
