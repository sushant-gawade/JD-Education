<?php
    require "_dbconnect.php";
    $num_event = 0;
    $q = "SELECT * FROM `event`";
    $res = mysqli_query($con,$q);
    $num_event = mysqli_num_rows($res);
    $q = "SELECT * FROM `courses`";
    $res = mysqli_query($con,$q);
    $num_course = mysqli_num_rows($res);
    mysqli_close($con);
?>

<section id="counts" class="counts section-bg">
    <div class="container">

        <div class="row counters">

            <div class="col-lg-3 col-6 text-center">
                <span class="counter">1232</span>
                <p>Students</p>
            </div>

            <div class="col-lg-3 col-6 text-center">
                <span class="counter"><?php echo $num_course*10;?></span>
                <p>Courses</p>
            </div>

            <div class="col-lg-3 col-6 text-center">
                <span class="counter"><?php echo $num_event*10;?></span>
                <p>Events</p>
            </div>

            <div class="col-lg-3 col-6 text-center">
                <span class="counter">15</span>
                <p>Teachers</p>
            </div>

        </div>

    </div>
</section>
<script>
    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });
    $('.counter').addClass('animated fadeInDownBig');
    $('h3').addClass('animated fadeIn');
</script>
