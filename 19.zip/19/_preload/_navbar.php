<?php
session_start();
?>
<link href="https://localhost/19/assets/css/style.css" rel="stylesheet">
<header id="header" class="fixed-top par_act">

  <div class="container d-flex align-items-center act">

    <h1 class="logo mr-auto"><a href="http://localhost/19/index.php" style="font-size: '32px';">JDE Education</a></h1>
    <nav class="nav-menu d-none d-lg-block">
      <ul class="lst_items">
        <li><a href="http://localhost/19/index.php">Home</a></li>
        <li><a href="http://localhost/19/about.html">About</a></li>
        <li><a href="http://localhost/19/courses.html">Courses</a></li>
        <li><a href="http://localhost/19/trainers.html">Teachers</a></li>
        <li><a href="http://localhost/19/events.html">Events</a></li>
        <li><a href="http://localhost/19/conference.html">Conference</a></li>
        <li><a href="http://localhost/19/contact.html">Contact</a></li>
        <li><a href="http://localhost/19/upload.html">Task</a></li>

    </nav>
    <a href="http://localhost/19/account.php" class="get-started-btn">Account</a>
    <script src="http://localhost/19/assets/js/main.js"></script>
  </div>
</header>
<script>
  function hide_s() {
    let lst_item = document.getElementsByClassName('lst_items')[0].children;
    let lst_item_mobile = document.getElementsByClassName('lst_items')[1].children;
    lst_item[2].style.display = "none";
    lst_item[3].style.display = "none";
    lst_item[4].style.display = "none";
    lst_item[5].style.display = "none";
    lst_item[7].style.display = "none";

    lst_item_mobile[2].style.display = "none";
    lst_item_mobile[3].style.display = "none";
    lst_item_mobile[4].style.display = "none";
    lst_item_mobile[5].style.display = "none";
    lst_item_mobile[7].style.display = "none";
    document.getElementsByClassName("active")[0].style.display = "none";
    console.log(document.getElementsByClassName("active")[0]);
  }

  function log_out() {
    let act_btn = document.getElementsByClassName("act")[0].children[2];
    act_btn.innerHTML = "Log Out"
    act_btn.setAttribute("href", "#")
    act_btn.addEventListener("click", function() {
      let xhr = new XMLHttpRequest();
      xhr.open("GET", "http://localhost/19/_preload/php/login_action.php", true)
      xhr.send();
      xhr.onreadystatechange = function() {
        if (xhr.status == 200 && xhr.readyState == 4) {
          window.location.href = "http://localhost/19/index.php"
        }
      }
    })
  }
</script>
<?php

if (isset($_SESSION['isEntered']) && $_SESSION['isEntered'] == true) {
  echo "<script>
      log_out();
    </script>";
} else {
  echo "<script>
    hide_s();
  </script>";
}
?>
<!-- <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="assets/vendor/counterup/counterup.min.js"></script>
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="assets/vendor/aos/aos.js"></script> -->