<?php
    if($_SERVER['REQUEST_METHOD'] == "POST"){
        session_start();
        $_SESSION['err'] = false;
        $_SESSION['isEntered'] = false;
        require "_dbconnect.php";
        $user = $_POST['username'];
        $pass = $_POST['password'];    
        $que = "SELECT * FROM `login_credit` WHERE username = '" . $user . "' AND password_hash = '".$pass. "'" ;
        $res = mysqli_query($con,$que);
        $num = mysqli_num_rows($res);
        mysqli_close($con);
        if($num == 1){
            $_SESSION['isEntered'] = true;
            header("Location: ../../index.php");
        }
        else{
            $_SESSION['isEntered'] = false;
            $_SESSION['err'] = true;
            header("Location: ../../index.php");
        }
    }
    if($_SERVER['REQUEST_METHOD'] == "GET"){
        session_start();
        $_SESSION['isEntered'] = false;
    }
?>